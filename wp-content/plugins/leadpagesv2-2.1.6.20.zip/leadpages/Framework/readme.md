###How to setup the Framework

*   Open Composer.json and change psr-4 namespace for app to your plugin name. This should be specific to your plugin to avoid name collision between plugins