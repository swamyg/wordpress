<?php


namespace LeadpagesMetrics\Interfaces;


interface EventEmail
{
    /**
     * Get Email for Event
     * @return mixed
     */
    public function getEmail();
}