<?php


namespace LeadpagesMetrics\Interfaces;


interface PlatformVersion
{

    /** Get Version Number
     * @return mixed
     */
    public function getPlatformVersion();

}